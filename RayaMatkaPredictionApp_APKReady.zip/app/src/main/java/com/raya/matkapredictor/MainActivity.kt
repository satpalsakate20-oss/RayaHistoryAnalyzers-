package com.raya.matkapredictor

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

data class Rec(val date:String,val jodi:Int,val open:Int,val close:Int)

class MainActivity:ComponentActivity(){
 override fun onCreate(b:Bundle?){super.onCreate(b);setContent{App()}}
}

@Composable
fun App(){
 var text by remember{mutableStateOf("")}
 var recs by remember{mutableStateOf(listOf<Rec>())}
 var out by remember{mutableStateOf(listOf<String>())}

 fun load(){
  recs=text.lines().mapNotNull{line->
   val p=line.trim().split(",", " ", "\t").filter{it.isNotBlank()}
   if(p.size>=4) try{Rec(p[0],p[1].toInt(),p[2].toInt(),p[3].toInt())}catch(_:Exception){null}else null
  }
  out=listOf("Loaded ${recs.size} records.")
 }
 fun predict(){
  if(recs.isEmpty()){out=listOf("Load history first.");return}
  val jf=IntArray(100);val pf=IntArray(1000);val df=IntArray(10)
  recs.forEach{r->
   jf[r.jodi]++
   r.open.coerceIn(0,999).let{pf[it]++}
   r.close.coerceIn(0,999).let{pf[it]++}
   r.jodi.toString().padStart(2,'0').forEach{df[it-'0']++}
  }
  val js=(0..99).sortedByDescending{j->
   val a=j/10;val b=j%10
   jf[j]*3+df[a]+df[b]+if(a==b)0 else 2
  }.take(5)
  out=js.map{j->
   val a=j/10;val b=j%10
   val ps=pf.indices.filter{pf[it]>0 && (it%10==a || it/100==b)}
    .sortedByDescending{pf[it]}.take(2)
   "Jodi ${j.toString().padStart(2,'0')} | Panna ${ps.joinToString("/") {it.toString().padStart(3,'0')}} | frequency ${jf[j]}"
  }
 }

 MaterialTheme{
  Scaffold(topBar={TopAppBar(title={Text("Raya Matka Analyzer")})}){pad->
   LazyColumn(Modifier.padding(pad).padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
    item{Text("Historical Prediction Analysis",style=MaterialTheme.typography.titleLarge)}
    item{Text("Statistical candidates only. No number can be guaranteed.")}
    item{
     OutlinedTextField(
      value=text,onValueChange={text=it},
      modifier=Modifier.fillMaxWidth().height(220.dp),
      label={Text("date,jodi,openPanna,closePanna")},
      placeholder={Text("2026-09-01,27,145,279\n2026-09-02,63,236,145")}
     )
    }
    item{
     Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){
      Button(onClick={load}){Text("Load")}
      Button(onClick={predict}){Text("Predict")}
      OutlinedButton(onClick={onClick@{text="";recs=listOf();out=listOf()}}){Text("Clear")}
     }
    }
    item{Text("Results",style=MaterialTheme.typography.titleMedium)}
    items(out){Text(it)}
   }
  }
 }
}
