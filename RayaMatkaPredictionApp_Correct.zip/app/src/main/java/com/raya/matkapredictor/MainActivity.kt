package com.raya.matkapredictor
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

data class R(val d:String,val j:Int,val o:Int,val c:Int)
class MainActivity:ComponentActivity(){override fun onCreate(b:Bundle?){super.onCreate(b);setContent{App()}}}

@Composable fun App(){
 var s by remember{mutableStateOf("")}; var rs by remember{mutableStateOf(listOf<R>())}; var out by remember{mutableStateOf(listOf<String>())}
 fun load(){rs=s.lines().mapNotNull{p->val x=p.trim().split(",", " ", "\t").filter{it.isNotBlank()};if(x.size>=4)try{R(x[0],x[1].toInt(),x[2].toInt(),x[3].toInt())}catch(_:Exception){null}else null};out=listOf("Loaded ${rs.size} records.")}
 fun pred(){if(rs.isEmpty()){out=listOf("Load history first.");return};val f=IntArray(100);val p=IntArray(1000);rs.forEach{f[it.j]++;if(it.o in 0..999)p[it.o]++;if(it.c in 0..999)p[it.c]++};out=(0..99).sortedByDescending{f[it]}.take(5).map{j->val q=p.indices.filter{p[it]>0}.sortedByDescending{p[it]}.take(2);"Jodi ${j.toString().padStart(2,'0')} | Panna ${q.joinToString("/") {it.toString().padStart(3,'0')}} | freq ${f[j]}"}}
 MaterialTheme{Scaffold(topBar={TopAppBar(title={Text("Raya Matka Analyzer")})}){pad->LazyColumn(Modifier.padding(pad).padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){item{Text("Historical Prediction Analysis",style=MaterialTheme.typography.titleLarge);Text("Statistical candidates only; no future result is guaranteed.")};item{OutlinedTextField(s,{s=it},Modifier.fillMaxWidth().height(220.dp),label={Text("date,jodi,openPanna,closePanna")})};item{Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){Button({load()}){Text("Load")};Button({pred()}){Text("Predict")};OutlinedButton({s="";rs=listOf();out=listOf()}){Text("Clear")}}};items(out){Text(it)}}}}}
